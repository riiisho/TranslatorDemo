import tkinter as tk
from tkinter import messagebox
import os

class Dictionary:
    
    def __init__(self):
        
        # GUI settings --
        self.root = tk.Tk() # makes GUI
        self.root.title("Dictionary") # makes the name of the GUI
        self.root.geometry("700x450") # sets the size of the GUI
        self.root.resizable(width=False, height=False) # makes it so the user cannot resize the GUI
        
        # title --
        self.title = tk.Label(self.root, text="Dictionary", font=('Arial', 18, 'bold'))
        self.title.pack(padx=10, pady=10)
        
        # makes a grid so labels are alligned --
        self.frame = tk.Frame(self.root)
        self.frame.columnconfigure(0, weight=1)
        self.frame.columnconfigure(1, weight=1)
        self.frame.columnconfigure(2, weight=1)
        self.frame.columnconfigure(3, weight=1)
        self.frame.columnconfigure(4, weight=1)
        self.frame.columnconfigure(5, weight=1)
        self.frame.columnconfigure(6, weight=1)
        self.frame.columnconfigure(7, weight=1)
        self.frame.columnconfigure(8, weight=1)
        self.frame.columnconfigure(9, weight=1)
        self.frame.columnconfigure(10, weight=1)
        self.frame.columnconfigure(11, weight=1)
    
        # labels --
        # english -
        self.english_heading=tk.Label(self.frame, text="English", font=('Arial', 16, 'bold'))
        self.english_heading.grid(row=0,column=0)
        self.english_1=tk.Label(self.frame, text="mineral water", font=('Arial', 14))
        self.english_1.grid(row=1,column=0)
        self.english_2=tk.Label(self.frame, text="a black coffee", font=('Arial', 14))
        self.english_2.grid(row=2,column=0)
        self.english_3=tk.Label(self.frame, text="tea with lemon", font=('Arial', 14))
        self.english_3.grid(row=3,column=0)
        self.english_4=tk.Label(self.frame, text="sugar", font=('Arial', 14))
        self.english_4.grid(row=4,column=0)
        self.english_5=tk.Label(self.frame, text="milk", font=('Arial', 14))
        self.english_5.grid(row=5,column=0)
        self.english_6=tk.Label(self.frame, text="salt", font=('Arial', 14))
        self.english_6.grid(row=6,column=0)
        self.english_7=tk.Label(self.frame, text="pepper", font=('Arial', 14))
        self.english_7.grid(row=7,column=0)
        self.english_8=tk.Label(self.frame, text="A table for two please.", font=('Arial', 14))
        self.english_8.grid(row=8,column=0)
        self.english_9=tk.Label(self.frame, text="Here is the menu.", font=('Arial', 14))
        self.english_9.grid(row=9,column=0)
        self.english_10=tk.Label(self.frame, text="Do you want to order?", font=('Arial', 14))
        self.english_10.grid(row=10,column=0)
        
        self.empty=tk.Label(self.frame, text="")
        self.empty.grid(row=0,column=1)
        # italian -
        self.italian_heading=tk.Label(self.frame, text="Italian", font=('Arial', 16, 'bold'))
        self.italian_heading.grid(row=0,column=2)
        self.italian_1=tk.Label(self.frame, text="acqua minerale", font=('Arial', 14))
        self.italian_1.grid(row=1,column=2)
        self.italian_2=tk.Label(self.frame, text="un caffè nero", font=('Arial', 14))
        self.italian_2.grid(row=2,column=2)
        self.italian_3=tk.Label(self.frame, text="tè con limone ", font=('Arial', 14))
        self.italian_3.grid(row=3,column=2)
        self.italian_4=tk.Label(self.frame, text="zucchero", font=('Arial', 14))
        self.italian_4.grid(row=4,column=2)
        self.italian_5=tk.Label(self.frame, text="latte", font=('Arial', 14))
        self.italian_5.grid(row=5,column=2)
        self.italian_6=tk.Label(self.frame, text="sale", font=('Arial', 14))
        self.italian_6.grid(row=6,column=2)
        self.italian_7=tk.Label(self.frame, text="pepe", font=('Arial', 14))
        self.italian_7.grid(row=7,column=2)
        self.italian_8=tk.Label(self.frame, text="Un tavolo per due, per favour.", font=('Arial', 14))
        self.italian_8.grid(row=8,column=2)
        self.italian_9=tk.Label(self.frame, text="Ecco il menu.", font=('Arial', 14))
        self.italian_9.grid(row=9,column=2)
        self.italian_10=tk.Label(self.frame, text="Volete ordinare?", font=('Arial', 14))
        self.italian_10.grid(row=10,column=2)
        
        self.empty=tk.Label(self.frame, text="")
        self.empty.grid(row=0,column=3)
        # polish
        self.italian_heading=tk.Label(self.frame, text="Polish", font=('Arial', 16, 'bold'))
        self.italian_heading.grid(row=0,column=4)
        self.italian_1=tk.Label(self.frame, text="woda mineralna", font=('Arial', 14))
        self.italian_1.grid(row=1,column=4)
        self.italian_2=tk.Label(self.frame, text="czama kawa", font=('Arial', 14))
        self.italian_2.grid(row=2,column=4)
        self.italian_3=tk.Label(self.frame, text="herbata z cytryną", font=('Arial', 14))
        self.italian_3.grid(row=3,column=4)
        self.italian_4=tk.Label(self.frame, text="Cukier", font=('Arial', 14))
        self.italian_4.grid(row=4,column=4)
        self.italian_5=tk.Label(self.frame, text="Mleko", font=('Arial', 14))
        self.italian_5.grid(row=5,column=4)
        self.italian_6=tk.Label(self.frame, text="sól", font=('Arial', 14))
        self.italian_6.grid(row=6,column=4)
        self.italian_7=tk.Label(self.frame, text="pieprz", font=('Arial', 14))
        self.italian_7.grid(row=7,column=4)
        self.italian_8=tk.Label(self.frame, text="Stolik dla dwojga proszę.", font=('Arial', 14))
        self.italian_8.grid(row=8,column=4)
        self.italian_9=tk.Label(self.frame, text="Ote menu.", font=('Arial', 14))
        self.italian_9.grid(row=9,column=4)
        self.italian_10=tk.Label(self.frame, text="Chcesz zamówić?", font=('Arial', 14))
        self.italian_10.grid(row=10,column=4)
        
        # button --
        self.back_button = tk.Button(self.frame, text="Back", font=('Arial', 16), bg="#DCDCDC", command=self.back)
        self.back_button.grid(row=11, column=0, sticky=tk.W+tk.E, pady=20)
        

        self.frame.pack(fill='x', padx=10, pady=10) # fills grid to fit GUI
        
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing) # prococol for deleting window
        self.root.mainloop()
        
    def back(self): # defines back button
        self.root.destroy()
        os.system('python AdminMenu.py')
   
    def on_closing(self): # brings up messagebox asking if you really want to quit when trying to exit
        if messagebox.askyesno(title="Quit?", message="Do you really want to quit?"):
            self.root.destroy()
            
Dictionary()