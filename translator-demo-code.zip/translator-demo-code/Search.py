import tkinter as tk
from tkinter import messagebox
import os

class Search:
    
    def __init__(self):
        
        # GUI settings --
        self.root = tk.Tk() # makes GUI
        self.root.title("Search") # makes the name of the GUI
        self.root.geometry("450x300") # sets the size of the GUI
        self.root.resizable(width=False, height=False) # makes it so the user cannot resize the GUI
        
        # title --
        self.title = tk.Label(self.root, text="Search Student", font=('Arial', 18, 'bold'))
        self.title.pack(padx=10, pady=10)
        
        # makes a grid so labels are alligned --
        self.frame = tk.Frame(self.root)
        self.frame.columnconfigure(0, weight=1)
        self.frame.columnconfigure(1, weight=1)
        self.frame.columnconfigure(2, weight=1)
        self.frame.columnconfigure(3, weight=1)
        self.frame.columnconfigure(4, weight=1)
    
        # dropdownmenu to select variable --
        self.class_dropdownmenu_variable=tk.StringVar(self.root)
        self.class_dropdownmenu_variable.set('Class 1')

        self.class_=tk.Label(self.root, text="Select Class:", font=('Arial', 8, 'italic'))
        self.class_.place(x=10, y=10)      
        self.class_option=tk.OptionMenu(self.root, self.class_dropdownmenu_variable, 'Class 1','Class 2','Class 3')
        self.class_option.place(x=10, y=30)

        
        # label and entry --
        self.empty=tk.Label(self.frame, text="", font=('Arial', 16))
        self.empty.grid(row=0,column=0)
        self.search_task=tk.Label(self.frame, text="Search for the following student:", font=('Arial', 16))
        self.search_task.grid(row=1,column=0)
        self.search_entry=tk.Entry(self.frame, justify='center', font=('Arial', 14))
        self.search_entry.grid(row=2,column=0, pady=10)
        
        # buttons --
        self.back_button = tk.Button(self.frame, text="Back", font=('Arial', 16), bg="#DCDCDC", width=100, command=self.back)
        self.back_button.grid(row=4, column=0, sticky=tk.W+tk.E, pady=10)
        
        self.submit_button = tk.Button(self.frame, text="Search", font=('Arial', 16), bg="#DCDCDC", command=self.check_search)
        self.submit_button.grid(row=3, column=0, sticky=tk.W+tk.E, pady=10)
  
        
        self.frame.pack(fill='x', padx=10, pady=10) # fills grid to fit GUI
        
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing) # prococol for deleting window
        self.root.mainloop()
        
    def back(self): # defines back button
        self.root.destroy()
        os.system('python AdminMenu.py')
    
    def check_search(self): # defines search button
        self.root.destroy()
   
    def on_closing(self): # brings up messagebox asking if you really want to quit when trying to exit
        if messagebox.askyesno(title="Quit?", message="Do you really want to quit?"):
            self.root.destroy()
            
Search()