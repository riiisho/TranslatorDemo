import tkinter as tk
from tkinter import messagebox
import os

class StudentLogin:
    
    def __init__(self):
        
        # GUI settings --
        self.root = tk.Tk() # makes GUI
        self.root.title("Login") # makes the name of the GUI
        self.root.geometry("250x250") # sets the size of the GUI
        self.root.resizable(width=False, height=False) # makes it so the user cannot resize the GUI
        
        # GUI Menubar -- ability to change from student login to admin login
        self.menubar = tk.Menu(self.root)
        self.adminmenu = tk.Menu(self.menubar, tearoff=0)
        self.adminmenu.add_command(label="Admin Login", command=self.admin_login_launch)
        self.menubar.add_cascade(menu=self.adminmenu, label="Student")
        self.root.config(menu=self.menubar)
        
        # makes a grid so labels are alligned --
        self.loginframe = tk.Frame(self.root)
        self.loginframe.columnconfigure(0, weight=1)
        self.loginframe.columnconfigure(1, weight=1)
        self.loginframe.columnconfigure(2, weight=1)
        self.loginframe.columnconfigure(3, weight=1)
        self.loginframe.columnconfigure(4, weight=1)
        
        # username label and entry --
        self.usernamelabel = tk.Label(self.loginframe, text="Username:", font=('Arial', 18))
        self.usernamelabel.grid(row=0, column=0, sticky=tk.W)
        
        self.usernameentry = tk.Entry(self.loginframe, font=('Arial', 16))
        self.usernameentry.grid(row=1, column=0, sticky=tk.W+tk.E)
        # password label and entry --
        self.passwordlabel = tk.Label(self.loginframe, text="Password:", font=('Arial', 18))
        self.passwordlabel.grid(row=2, column=0, sticky=tk.W, pady=10)
        
        self.passwordentry = tk.Entry(self.loginframe, font=('Arial', 16))
        self.passwordentry.config(show="*")
        self.passwordentry.grid(row=3, column=0, sticky=tk.W+tk.E)
        # button --
        self.loginbutton = tk.Button(self.loginframe, text="Login", font=('Arial', 18), bg="#DCDCDC", command=self.check_credentials)
        self.loginbutton.grid(row=4, column=0, sticky=tk.W+tk.E, pady=20)
        
        
        self.loginframe.pack(fill='x', padx=10, pady=10) # fills grid to fit GUI
        
        self.root.mainloop()
     
     
    def check_credentials(self): # checks the entrys to see if it the same as the set credentials
        studentusername = "student"
        studentpassword = "student"
        if self.usernameentry.get() == studentusername:
            if self.passwordentry.get() == studentpassword: # if username and password is correct it launches the menu
                messagebox.showinfo("Credentials correct","You can now access the translator program")
                self.root.destroy()
                os.system('python StudentMenu.py')
            else:
                messagebox.showwarning("Password incorrect","Please re-enter your password")
        else:
            messagebox.showwarning("Username incorrect","Please re-enter your username")
          
    def admin_login_launch(self): # defines admin cascade to launch the admin version of login which has different credentials
        if messagebox.askyesno(title="Admin login", message="Are you sure you want to login as an admin?"):
            self.root.destroy()
            os.system('python AdminLogin.py')
            
StudentLogin()       