import tkinter as tk
from tkinter import messagebox
import os

class StudentMenu:
    
    def __init__(self):
        
        # GUI settings --
        self.root = tk.Tk() # makes GUI
        self.root.title("Student Menu") # makes the name of the GUI
        self.root.geometry("250x300") # sets the size of the GUI
        self.root.resizable(width=False, height=False) # makes it so the user cannot resize the GUI
        
        # makes a grid so labels are alligned --
        self.menuframe = tk.Frame(self.root)
        self.menuframe.columnconfigure(0, weight=1)
        self.menuframe.columnconfigure(1, weight=1)
        self.menuframe.columnconfigure(2, weight=1)
        self.menuframe.columnconfigure(3, weight=1)

        # buttons --
        self.button1 = tk.Button(self.menuframe, text="Activity 1", font=('Arial', 18), bg="#DCDCDC", width=100, command=self.launch1)
        self.button1.grid(row=0, column=0, sticky=tk.W+tk.E)
        
        self.button2 = tk.Button(self.menuframe, text="Activity 2", font=('Arial', 18), bg="#DCDCDC", command=self.launch2)
        self.button2.grid(row=1, column=0, sticky=tk.W+tk.E, pady=10)
        
        self.button3 = tk.Button(self.menuframe, text="Activity 3", font=('Arial', 18), bg="#DCDCDC", command=self.launch3)
        self.button3.grid(row=2, column=0, sticky=tk.W+tk.E)
        
        self.button4 = tk.Button(self.menuframe, text="Settings", font=('Arial', 18), bg="#DCDCDC", command=self.launch4)
        self.button4.grid(row=3, column=0, sticky=tk.W+tk.E, pady=10)
        
        self.button4 = tk.Button(self.menuframe, text="Logout", font=('Arial', 18), bg="#C0C0C0", command=self.launch5)
        self.button4.grid(row=4, column=0, sticky=tk.W+tk.E)
        
        
        self.menuframe.pack(fill='x', padx=10, pady=10) # fills grid to fit GUI
        
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing) # prococol for deleting window
        self.root.mainloop()
        
        
    def launch1(self): # defines first button
        self.root.destroy()
    
    def launch2(self): # defines second button
        self.root.destroy()
        os.system('python Activity2.py')
    
    def launch3(self): # defines third button
        self.root.destroy()
    
    def launch4(self): # defines fourth button
        self.root.destroy()
        
    def launch5(self): # defines fifth button
        self.root.destroy()
        os.system('python StudentLogin.py')
    
    def on_closing(self): # brings up messagebox asking if you really want to quit when trying to exit
        if messagebox.askyesno(title="Quit?", message="Do you really want to quit?"):
            self.root.destroy()
    
StudentMenu()